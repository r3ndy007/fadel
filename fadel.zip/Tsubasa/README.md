# Tsubasa BOT
BOT Click: [TSUBASA BOT](https://t.me/TsubasaRivalsBot/start?startapp=inviter_id-921415493) 

## Features:

* Thẻ nâng cấp tự động
* Ưu tiên nâng cấp thẻ có lợi nhuận cao
* Tự động hoàn thành nhiệm vụ
* Điểm danh tự động hằng ngày


## Module:

- Python 3.7 trở lên
- `pip` (trình cài đặt gói Python)

## Installation
1. **Clone this repository:**
   - Mở cmd hoặc Shell, sau đó chạy lệnh:
    ```sh
    git clone https://github.com/thog9/Tsubasa-bot.git
    ```
    ```sh
    cd Tsubasa-bot
    ```
2. **Install Module:**
   - Mở cmd hoặc Shell, sau đó chạy lệnh:
    ```sh
    pip install -r requirements.txt
    ```
3. **Chạy:**
- Mở cmd hoặc Shell, sau đó chạy lệnh:
    ```sh
    python bot.py
    ```

